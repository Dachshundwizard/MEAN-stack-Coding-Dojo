This repo contains the MEAN stack application that is built through Full Stack Training's MEAN stack course.

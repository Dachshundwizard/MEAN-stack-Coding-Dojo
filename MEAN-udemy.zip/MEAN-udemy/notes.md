We have npm installed Express and package.JSON.

+ Package.JSON will manage our dependancies.
    - If you go into package.json, you can see express is located in 'dependancies'

+ First entered in our start: node app.js
    - Then to run this, you use npm start, same as node app.js

-----------------------------------

+ Adding express to the application
    + Express is the web application framework in the MEAN stack. So it listens for incoming request and responds.
    - First thing we want express to do is to listen for requests
    - ps -ax | grep node to kill the node
+ Defining a port to listen on

+ Using application variables

+ Validating that express is listening

+ Defining URL routes

+ Returning status codes

+ responding with data

+ Sending HTML response

+ SERVING STATIC FILES FROM express

    + Defining static folders

    + Build basic HTML page

    + Deliver CSS, images and JS

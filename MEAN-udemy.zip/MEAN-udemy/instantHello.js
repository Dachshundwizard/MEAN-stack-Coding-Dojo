var name = "Everyone!";
console.log("Hello " + name);

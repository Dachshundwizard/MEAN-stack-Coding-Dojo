//////Answer #1///////////////////////////////////////////////////////////////////////////

var first_variable;//Undefined
function firstFunc() { //functions are hoisted right under where initial variable is declared.
  first_variable = "Not anymore!!!";
  console.log(first_variable);
}

console.log(first_variable);
first_variable = "Yipee I was first!";
console.log(first_variable);

//////Answer #2///////////////////////////////////////////////////////////////////////////
var food;

function eat() {
    var food;
    food = "half-chicken";
    console.log(food);
    food = "gone";
    console.log(food);
}

food = "Chicken";
eat();
console.log(food);

//////Answer #3///////////////////////////////////////////////////////////////////////////
var new_word;

function lastFunc() {
  new_word = "old";
}

new_word = "NEW!";

console.log(new_word);

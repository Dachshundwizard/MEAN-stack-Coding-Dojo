#Quoting Dojo

1. Dependencies
    + 'body-parser'
    + 'express'
    + 'mongoose'
    + 'ejs'

2. Views
    + 'welcome.ejs'
        + Form to create a new quote 

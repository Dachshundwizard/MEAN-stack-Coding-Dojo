$(document).ready(function(){
    $('button').on('click', function(){
        $.get("https://api.github.com/users/Quint436", displayName)
        function displayName(data) {
            $('button').append('<p class="name">' + data.name + '</p>');
        }
    });
});
